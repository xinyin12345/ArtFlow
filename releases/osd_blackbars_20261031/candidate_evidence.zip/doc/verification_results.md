# CAP/OUT verification results — final physical PASS

- Questa Altera Starter FPGA Edition 2025.3: no Error/Fatal in passing runs.
- 13 full 1080p RTL frames, 27,027,156 timing cycles; independent bitmap/glyph
  reference matches 26,956,800 active pixels. Generated PNGs are RTL output.
- FPS: 4 legacy windows + 8 extended windows including 29/30/31, independent
  stopped windows, saturation, sample-boundary events and reset; UI 12 checks.
- Layout equivalence: baseline vs candidate AXI, video and stream outputs cycle
  for cycle; 81,920 checked active pixels across three layouts (4/3/3 frames).
  Actual read-snapshot style mailbox and frame-stable metadata checks passed.
- Pair/freeze: 36 scenarios, 33 successful completions, one injected job failure;
  published style is preserved on failure. Eight-style cycle, replacement,
  invalid header, out-of-range slot and missing-Flash recovery all passed.
- System: actual pipe/mux/FIFOs/scheduler and CNN wrapper/CDC with transaction
  engine fixture; 8 jobs, 15 renders, 44 captures, 55,296 checked pixels.
  The one initial underflow matches accepted baseline summary exactly; it is
  not claimed as zero-underflow startup. This is not a new CNN arithmetic test.
- SPI: 95 packets, valid/CRC/error/overflow/reset; 50 asynchronous reset positions,
  11 complete packets cycle-equivalent; 11 display-tap cases; RTL->C receiver
  28,800 exact pixels; protocol diagnostics, actual loopback WebSocket payload
  and browser decoder/disconnect/reconnect regression passed.
- Actual OSD-output VS telemetry: 8 one-second windows, 30 checks; freeze OUT=30,
  no-output public OUT=0 without waiting for VS; 29/30/31 and wide VS pulses.
- Fresh Efinity map: 38,530 LUT4 / 25,807 FF; delta -191 LUT4 / +4 FF / +1 ADD;
  RAM 253/256 and DSP 144 remain unchanged. CAP/OUT final physical flow passed; see outputs/FINAL_ACCEPTANCE.md.

Coverage is directed functional/cycle/pixel evidence, not line/toggle/formal
coverage closure. The native-RAM testbench emits expected primitive model and
unused-port warnings; full OSD raster simulation has zero warnings.
No programming or on-board validation has been performed.

All receipts and hashes are collected in `reports/regression_complete.json`.
Earlier PRC Library previews were created successfully; Windows metadata helper
failed because os.setxattr is unavailable. CAP/OUT replacement status is recorded
separately in reports/library_out_replace_receipt.json when attempted. No duplicate
file creation is authorized or required. All prior PRC reports are archived.

## Final physical result

PASS: legal routing, final normal setup/hold, original CDC/IO budget gates, new OSD coherent-mailbox path bounds and bit/hex file generation. See `reports/physical_gate.json`, `reports/osd_cdc.json` and `reports/delivery.json`. No board test performed.
