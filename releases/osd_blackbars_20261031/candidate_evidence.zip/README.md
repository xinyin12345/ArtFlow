# ArtFlow black-bar OSD preview — independent Process candidate

Baseline: `D:/work/FPGA/ArtFlow/ArtFlow`. This candidate is in
`D:/work/FPGA/ArtFlow/Process/osd_blackbars_20261030`.
No main-project edits, Git operations, JTAG, Flash or serial programming.
The separate gesture candidate is not part of this snapshot and is not modified.

## Preview and status

`outputs/rtl_frame_00.png` is a real 1920x1080 RTL simulation output, with a
coordinate-coded test image (not camera/stylization inference). CAP=030 / OUT=030
are testbench telemetry inputs, not measured board performance.
`outputs/rtl_8_styles.png` is a review contact sheet built from real RTL frames.
The full frame set and validation completion are recorded in `reports/`.
The final bit is generated and passed offline physical gates; see outputs/FINAL_ACCEPTANCE.md. Board validation remains pending.

## Display behavior

- DUAL: original image x=0..959 and styled image x=960..1919, y=270..809.
  Top and bottom 270-row black bars are now dark gray status panels.
- Original 8x8 glyphs in osd_font.mem (including N/K) are reused unchanged.
  build_osd_text_rows.py derives a 256-character aligned atlas in one 2048x5
  RAM; three constant-zero columns reconstruct the unchanged 8x8 glyphs, replacing combinational ASCII string decoding. Title is x8 and body x4.
  The color pipeline stores a 3-bit palette index; two-register latency, RGB
  values and every preview pixel remain identical. No additional RAM or alpha.
- Top: ARTFLOW, DUAL, centered ORIGINAL and actual displayed style name.
- Styles 0..7: STAINED GLASS, SKETCH, OIL PAINTING, STARRY NIGHT,
  HALFTONE COMIC, SAND ART, INK, RICH WOODCUT.
- CAP/OUT have 480-pixel bars representing 0..30 fps; values above 30 clamp.
  The white tick is 30 fps. Valid values >=30 are green; lower values red.
  Before the first one-second sample, bars are empty and digits show `---`.
- The eight selector cells show IDs 0..7; the actually displayed style is yellow.
  Before a styled result is available, the label reads WAITING with no selection.
- Horizontal borders y=269/810 are outside the source image. Vertical borders
  occupy x=0/1919 and the central four pixels x=958..961. All other image pixels
  are identical, with unchanged OSD two-register latency.
- KEY1 still selects DUAL / STYLE fullscreen / ORIG fullscreen. Fullscreen keeps
  native 1920x1080 imagery; only a compact HUD x=32..799,y=32..127 is overlaid.
  There are no synthetic black bars or fullscreen image rescaling.
- KEY2 toggles all OSD decoration; disabled output is the two-register baseline
  RGB and timing copy. KEY3 and UART behavior are unchanged.

## Telemetry and clock crossing

CAP counts complete successful DDR capture publications. OUT counts actual rising
VS edges at the OSD output connected to the TMDS encoder. It uses the existing
independent one-second pixel-clock timer, saturated BCD 000..999, rather than a
nominal constant or processing completions. Freeze repeats an image while OUT
continues counting HDMI rasters. Internal PRC/serial diagnostics retain their
existing meaning and are not displayed.

The target markers are both 30 fps. OUT's configured geometry is
74.25 MHz / (2200 * 1125) = 30 Hz. CAP's existing P1 acceptance goal is about
30 fps (baseline `doc/baseline_v04/board_acceptance.md`); `firmware/src/camera.c` explicitly
warns that sensor line time is unmeasured, so register settings alone do not
prove measured CAP rate. The numbers always come from observed events.

When VS stops but the pixel clock runs, a complete zero-event window updates
the public OUT value to zero without waiting for a further frame (within two
seconds for an arbitrary stop phase). A stopped HDMI clock cannot measure time
or draw status; with no output raster, zero is observable in RTL telemetry and
on the first resumed frame, not on an absent physical video signal.

The controller records the style only on successful publication, preserving it
on failure. The display reader snapshots that style with the selected bank.
A bundled-data request/acknowledge mailbox transfers the four-bit valid/style
payload; it is held until acknowledgment and captured after three request stages.
The label is latched at the first active pixel after vertical blanking and held
through the raster. It is never sourced from requested style or independent
per-bit synchronization. The mailbox is read-only and does not control AXI,
frame ownership, rendering, or the pre-OSD stream tap.

## Current validation status

The final CAP/OUT implementation passed a fresh 13-frame simulation and independent
26,956,800-pixel comparison. All original frame/PNG hashes are unchanged. Other
unaffected regressions were reused only after their source and report hashes matched.
Synthesis: 38,530 LUT4 / 25,807 FF (-191 / +4 versus baseline), RAM 253 and DSP 144.
Final placement: 58,112 / 60,800 XLR. Routing succeeded at iteration 46 with zero
resource overlaps. Final normal setup/hold minima: +0.313 / +0.026 ns, all ten
applicable clocks. All applicable CDC gates pass; external SPI/ESP budgets retain
the documented board assumptions. Independent bit/hex generated; no board testing,
JTAG, Flash programming, ESP firmware operations, Git commit or push performed.
See outputs/FINAL_ACCEPTANCE.md, reports/physical_gate.json and reports/delivery.json.

## Reproduction

Use local Python 3 with Pillow and the installed Questa 2025.3 / Efinity 2026.1.
Run `tools/run_osd_tests.py`, then `tools/check_osd_frames.py`.
Run `tools/run_osd_regression.py` then `tools/finalize_osd_out.py` for
source-associated layout/stream equivalence, FPS, style cycle,
freeze control, system rendering and SPI/ESP checks. Logs live under `work/`
and `stream/logs/`. The snapshot includes historical helpers: the OSD-specific
scripts above are the supported entry points for this candidate.

Final build: set OSD_MAP_THREADS=16 and OSD_MAP_MODE=speed, run `tools/run_osd_flow.py map`, `interface`, then `tools/run_osd_physical_attempt.py TIMING_3 2 5 16` and `tools/finish_osd_physical.py`. Existing flow logs
are preserved, so inspect/archive a failed attempt before retrying. PGM generates
files only and is gated by `reports/physical_gate.json`; it never programs a board.
Source hashes: `baseline/source_sha256.json`, `reports/implementation_sha256.json`.

### Archived PRC revision: historical area and build history

The archived PRC revision had a measured whole-design net delta of +72 LUT4. The OSD placement hierarchy
itself estimates 601 LUT4 versus 151 previously (+450); optimizations elsewhere
offset part of that increase. It is not a claim that this UI inherently costs 72 LUTs.

The first PNR invocation combined two command-line options incorrectly. Efinity
ignored the combined optimization value and used its default threading. That run
was stopped deliberately (not a proven congestion failure) and fully archived in
`work/osd_attempt1_invalid_options`. The second invocation used verified separate `optimization_level=TIMING_3` and
`max_threads=2` parameters. It was deliberately stopped at routing iteration 42
with 3,795 overlapping resources, after a sustained plateau. Its exit 0xffffffff
was caused by that explicit supervised stop, not a spontaneous tool crash. Full
evidence is retained in `work/osd_attempt2_timing3_plateau`. The third attempt uses
`optimization_level=CONGESTION_3`, two threads, the same RTL/map and constraints;
it was later stopped on the CAP/OUT requirement change and is historical evidence only.

## Preview delivery

Exactly two authorized preview PNGs were created through the official Library
host upload API. Confirmed IDs and per-file statuses are in
`reports/library_upload_receipt.json`. The prepared-upload helper was unavailable.
The official local metadata helper then failed on Windows because Python has no
`os.setxattr`; no metadata workaround or duplicate upload was attempted. Cloud
file creation succeeded, while automatic local Library tracking is unavailable.
The PNGs are actual RTL simulations with coordinate-coded input and test telemetry,
not camera captures or measured board performance.

## PRC-to-OUT revision

The third PRC physical attempt was explicitly stopped on the new requirement
(owned PID 31700), before final routing. Its summary records
`ABORTED_SUPERVISED_REQUIREMENT_CHANGE`. Fresh map/PNR is required for CAP/OUT.

## Updated preview versions

The same two Library file identities now contain CAP/OUT previews, version 1.
Their replacement was confirmed by Library read; see
`reports/library_out_replace_receipt.json`. The initial optimistic version
conflict was resolved by refreshing unchanged version 0 before replacing it.
Local xattr tracking remains unsupported by the official helper on Windows.

## Local takeover and compact implementation

The former remote owner confirmed exclusive handoff to the local task. Baseline
1078-file and 241-file original implementation manifests were rechecked, as were
all 12 functional receipts. Gesture files are excluded from all 73 design entries
and the mapped netlist. Three local valid PNR attempts on the original CAP/OUT
implementation naturally failed on congestion; a separate invalid NULL option
attempt was explicitly stopped and is not classified as a natural failure.

The compact OSD changed only the OSD implementation plus its derived ROM. Fresh
13-frame simulation and independent comparison passed 26,956,800 pixels. All
13 frame hashes and all PNG hashes match the former CAP/OUT implementation.
Unchanged functional regression evidence was revalidated against source hashes.
See reports/compact_osd_change.json and reports/resource_comparison.json.
Final physical configuration: TIMING_3, seed 2, placer effort 5, max threads 16; synthesis speed, max threads 16. Physical gates and bit generation passed.

## Aligned ROM optimization

The original 8x8 glyphs use five nonzero columns. The current ROM stores 2048x5 bits in one EFX_RAM10, with aligned 16-character groups. All 13 RTL frame hashes and preview PNG hashes match the earlier CAP/OUT implementation exactly; two-register latency is unchanged. Current map: 38,530 LUT4, 25,807 FF, 253 RAM blocks and 144 DSP blocks. Physical validation passed. See reports/compact_osd_change.json.

## Final physical result

Legal routing, final setup/hold and all physical audits passed. Independent bit/hex generated in `outputs/`; see `reports/delivery.json` and `outputs/README_delivery.md`. No hardware programming.
