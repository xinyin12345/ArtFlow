from pathlib import Path
import json,hashlib,datetime,difflib
R=Path(__file__).resolve().parents[1];B=Path(r'D:\work\FPGA\ArtFlow\ArtFlow')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=['reports/osd_simulation.json','reports/pixel_comparison.json']+[f'work/osd_reg_{n}/summary.json' for n in ['fps_edges','layout_equivalence','pair_control','style_cycle','system']]+[f'stream/logs/{n}' for n in ['rtl/summary.json','reset-equivalence/summary.json','tap/summary.json','host-tests.json','browser-tests.json']]
rows=[]
for name in paths:
 p=R/name;d=json.loads(p.read_text());assert d['status']=='PASS',(name,d)
 keys=['source_sha256','vector_sha256']+(['sha256'] if name=='reports/osd_simulation.json' else [])
 for key in keys:
  for f,h in d.get(key,{}).items():
   q=Path(f)
   if not q.is_absolute():q=(R/'stream'/q) if name=='stream/logs/host-tests.json' else R/q
   assert sha(q)==h,('Stale evidence',name,str(q))
 rows.append({'report':name,'sha256':sha(p),'evidence':d.get('evidence',d.get('results',{}))})
pixels=json.loads((R/'reports/pixel_comparison.json').read_text());assert pixels['total_pixels']==26956800
assert all('outfps' in f and 'prc' not in f for f in pixels['frames'])
top=(R/'rtl/ArtFlow_top.v').read_text(encoding='latin-1')
assert '.capture_toggle(capture_toggle),.i_vs(osd_vs)' in top
assert '.capture_bcd(capture_fps_bcd),.display_bcd(display_fps_bcd),.fps_valid(fps_valid)' in top
old=(R/'work/prc_revision_archive/rtl/ArtFlow_top.v').read_text(encoding='latin-1')
extract=lambda s:s.split('reg [11:0] process_fps_bcd=0;',1)[1].split(' else if(hdmi_tx_vs) process_fps_bcd<=process_sample;',1)[0]
assert extract(top)==extract(old),'Internal PRC source changed'
result={'status':'PASS','revision':'CAP_OUT','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cases':rows,'actual_output_event':'osd_vs rising edge at TMDS encoder input','clock_hz':74250000,'targets_fps':{'CAP':30,'OUT':30},'CAP_target_basis':'Existing camera goal ~30 in baseline doc/baseline_v04/board_acceptance.md; not inferred sensor rate; camera.c warns unmeasured line time','stop_limit':'Running pixel clock: public zero after complete idle one-second window without waiting for VS; stopped clock cannot measure time/draw status','note':'System fixture one startup underflow matches baseline; no board test; unchanged PRC source/serial diagnostic semantics'}
(R/'reports/regression_complete.json').write_text(json.dumps(result,indent=2));(R/'reports/styles8/round23t_functional_receipt.json').write_text(json.dumps(result,indent=2))
baseline=json.loads((R/'baseline/source_sha256.json').read_text(encoding='utf-8-sig'));changed=[];main_changed=[];patch=''
for item in baseline:
 n=item['path'].replace('\\','/');p=R/n;bp=B/n
 if bp.is_file() and sha(bp).lower()!=item['sha256'].lower():main_changed.append(n)
 if p.is_file() and sha(p).lower()!=item['sha256'].lower():
  changed.append(n)
  if n.startswith('rtl/'):
   patch+=''.join(difflib.unified_diff(bp.read_text(encoding='latin-1').splitlines(True),p.read_text(encoding='latin-1').splitlines(True),fromfile='a/'+n,tofile='b/'+n))
assert not main_changed,main_changed
(R/'reports/source_diff.json').write_text(json.dumps({'revision':'CAP_OUT','baseline_changed_since_snapshot':main_changed,'candidate_changed':changed},indent=2))
(R/'outputs/osd_source_changes.patch').write_text(patch,encoding='latin-1')
for n in ['verification_plan.md','case_list.md']:
 p=R/'doc'/n;s=p.read_text().replace('0/14/15/16/30/999','0/29/30/31/999').replace('14/15/16 counts','29/30/31 counts');p.write_text(s)
p=R/'doc/case_list.md';s=p.read_text();s=s.split('\n9. tb_osd_output_telemetry:',1)[0];s+='\n9. tb_osd_output_telemetry: real OSD output VS into UI counter; 8 windows,\n   30 checks, three-cycle VS pulses counted once, 29/30/31 counts, frozen RGB\n   with OUT=30, stopped VS updates public OUT=0 without another frame.\n';p.write_text(s)
p=R/'doc/verification_results.md';s=(R/'work/prc_revision_archive/doc/verification_results.md').read_text(encoding='utf-8')
s=s.replace('# Verification results (physical flow pending)','# CAP/OUT verification results (physical flow pending)').replace('14/15/16','29/30/31')
start=s.index('- Actual Efinity map PASS:');end=s.index('\nCoverage',start)
m=json.loads((R/'reports/resource_comparison.json').read_text());c=m['candidate'];d=m['delta']
s=s[:start]+f'''- Actual OSD-output VS telemetry: 8 one-second windows, 30 checks; freeze OUT=30,
  no-output public OUT=0 without waiting for VS; 29/30/31 and wide VS pulses.
- Fresh Efinity map: {c['EFX_LUT4']:,} LUT4 / {c['EFX_FF']:,} FF; delta {d['EFX_LUT4']:+} LUT4 / {d['EFX_FF']:+} FF / {d['EFX_ADD']:+} ADD;
  RAM 253/256 and DSP 144 remain unchanged. CAP/OUT physical flow is pending.
'''+s[end:]
start=s.index('Library preview upload was rejected')
s=s[:start]+'''Earlier PRC Library previews were created successfully; Windows metadata helper
failed because os.setxattr is unavailable. CAP/OUT replacement status is recorded
separately in reports/library_out_replace_receipt.json when attempted. No duplicate
file creation is authorized or required. All prior PRC reports are archived.
'''
p.write_text(s,encoding='utf-8')
p=R/'reports/progress.json';g=json.loads(p.read_text());g.update(regression_status='PASS_CAP_OUT',rtl_pixels=26956800,preview_revision='CAP_OUT_RTL_READY',utc=result['utc']);p.write_text(json.dumps(g,indent=2))
print('PASS fresh CAP/OUT regressions and source-associated evidence; no board release yet')
