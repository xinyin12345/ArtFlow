from pathlib import Path
import json,time,subprocess,sys,shutil,hashlib,datetime,re
R=Path(__file__).resolve().parents[1];W=R/'work/osd_impl';O=R/'outputs'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def state(stage,**extra):
 p=R/'reports/progress.json';d=json.loads(p.read_text());d.update(stage=stage,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),**extra);p.write_text(json.dumps(d,indent=2))
def run(script,*args):
 subprocess.run([sys.executable,'-B',str(R/script),*args],cwd=R,check=True)
try:
 start=json.loads((W/'pnr_process.json').read_text())['start'];last=0
 while not (W/'pnr_summary.json').exists():
  if time.monotonic()-last>=30:
   last=time.monotonic();phase='PLACEMENT';p=W/'out/ArtFlow.place.out';q=W/'out/ArtFlow.route.out'
   if q.exists() and q.stat().st_mtime>start:phase='ROUTING';p=q
   tail=p.read_text(errors='replace').splitlines()[-3:] if p.exists() else []
   state('OUT_ROUTE_TIMING3_'+phase,last_log=tail,previous_route_log_is_stale=phase=='PLACEMENT')
  time.sleep(5)
 assert json.loads((W/'pnr_summary.json').read_text())['status']=='PASS','PNR failed; see logs'
 while json.loads((R/'reports/regression_complete.json').read_text()).get('revision')!='CAP_OUT':
  state('OUT_PNR_DONE_WAITING_FRESH_FUNCTIONAL_RECEIPT');time.sleep(15)
 state('PNR_COMPLETE_PHYSICAL_AUDITS_RUNNING')
 shutil.copy2(W/'out/ArtFlow.timing.rpt',R/'reports/normal_routed_timing.rpt')
 run('tools/run_osd_audits.py')
 state('PHYSICAL_GATES_PASS_GENERATING_BIT')
 run('tools/run_osd_flow.py','pgm')
 for ext in ['bit','hex']:
  src=W/f'out/ArtFlow.{ext}';dst=O/f'ArtFlow_osd_blackbars_20261030.{ext}'
  assert src.is_file() and src.stat().st_size>100000
  if dst.exists():assert sha(dst)==sha(src),'Refuse overwriting different delivery'
  else:shutil.copy2(src,dst)
 files=[O/f'ArtFlow_osd_blackbars_20261030.{e}' for e in ['bit','hex']]
 (O/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in files))
 gate=json.loads((R/'reports/physical_gate.json').read_text())
 delivery={'status':'PASS_OFFLINE_READY_FOR_USER_BOARD_TEST','files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in files},'gates':gate,'hardware_programmed':False,'git_committed':False,'main_project_modified':False,'library_previews':json.loads((R/'reports/progress.json').read_text()).get('library_upload'),'scope':'OSD-only Process candidate; separate gesture candidate not included'}
 (R/'reports/delivery.json').write_text(json.dumps(delivery,indent=2))
 (O/'README_delivery.md').write_text('''# OSD 预览候选交付

本目录中的 `ArtFlow_osd_blackbars_20261030.bit` / `.hex` 是独立 Process 候选。
已经通过合法布线、正常约束下最终 setup/hold、原有 CDC/接口预算和新增 OSD
握手路径审计，以及完整功能回归。尚未烧录或实板验证，没有 Git 提交。

这是 8 风格、1080p30 HDMI 与既有 ESP 推流基线的 OSD 改动，不含另一个任务的
手势模型候选。原模型权重、按键/UART、冻结/curtain 等功能与推流保留。

`rtl_frame_00.png` 为完整 RTL 仿真帧；`rtl_8_styles.png` 是 8 种标签的实际 RTL
帧裁剪缩略合集。背景是坐标编码测试图，CAP/OUT 是测试输入，不是实板测速。
KEY1 仍切换双窗口/风格全屏/原图全屏，KEY2 关闭全部 OSD，KEY3 仍切换风格。
双窗口 OSD 使用上下空区；全屏只显示紧凑 HUD，不缩小原图。

请先核对 SHA256SUMS.txt。板上效果、实际帧率与外部 SPI 电气裕量仍需用户验收。
工程与完整证据见上一级 README.md、doc/verification_results.md 和 reports/。
''',encoding='utf-8')
 with (R/'README.md').open('a',encoding='utf-8') as f:
  f.write('\n## Final physical result\n\nLegal routing, final setup/hold and all physical audits passed. Independent bit/hex generated in `outputs/`; see `reports/delivery.json` and `outputs/README_delivery.md`. No hardware programming.\n')
 with (R/'doc/verification_results.md').open('a',encoding='utf-8') as f:
  f.write('\n## Final physical result\n\nPASS: legal routing, final normal setup/hold, original CDC/IO budget gates, new OSD coherent-mailbox path bounds and bit/hex file generation. See `reports/physical_gate.json`, `reports/osd_cdc.json` and `reports/delivery.json`. No board test performed.\n')
 state('COMPLETE_OFFLINE_BIT_READY',bit=str(files[0]),physical_status='PASS')
 print('COMPLETE',files[0],flush=True)
except Exception as e:
 state('PHYSICAL_FLOW_NEEDS_ATTENTION',error=str(e));raise
